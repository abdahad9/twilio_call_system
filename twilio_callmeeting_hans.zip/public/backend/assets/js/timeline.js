$('.timeline').timelify({
	animLeft: "fadeInLeft",
	animCenter: "fadeInUp",
	animRight: "fadeInRight",
	animSpeed: 600,
	offset: 150
});